package com.jcb.controller;

import com.jcb.bean.Address;
import com.jcb.bean.AdmAddress;
import com.jcb.bean.Admin;
import com.jcb.bean.Customer;
import com.jcb.bean.FinalCart;
import com.jcb.bean.Item;
import com.jcb.bean.TempCart;
import com.jcb.dao.JcbDAO;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

@MultipartConfig(maxFileSize = 16177215)
public class JCBController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	final static Logger logger = Logger.getLogger(JCBController.class);

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		response.setHeader("Pragma", "no-cache");
		if(request.getParameter("action") != null){
			String action = request.getParameter("action");
			request.setAttribute("group", request.getParameter("group"));
			String url = "";
			if(action.equals("index")){
				url = "WEB-INF/index.jsp";
			}else if(action.equals("Add_medicine")){
				url = "WEB-INF/Add_medicine.jsp";
			}else if(action.equals("userhome")){
				url = "WEB-INF/userhome.jsp";
			}else if(action.equals("View_Medicine")){
					url = "WEB-INF/View_Medicine.jsp";
			}else if(action.equals("userprofile")){
				url = "WEB-INF/UserAccount.jsp";
			}else if(action.equals("adminprofile")){
				url = "WEB-INF/Admin_Account.jsp";
			}else if(action.equals("Request_Medicine")){
				url = "WEB-INF/Request_Medicine.jsp";
			}else if(action.equals("trackmedicine")){
				url = "WEB-INF/Track_Medicine.jsp";
			}else if(action.equals("adminPanel")){
				url = "WEB-INF/adminPanel.jsp";
			}else if(action.equals("viewrequest")){
				url = "WEB-INF/View_Request.jsp";
			}else if(action.equals("User_list")){
				url = "WEB-INF/User_list.jsp";
			
				
			}else if(action.equals("success")){
				url = "WEB-INF/Success.jsp";
			}else if(action.equals("logout")){
				HttpSession ses = request.getSession(false);
				if (ses != null) {
					ses.removeAttribute("id");
					ses.removeAttribute("roll");
					ses.invalidate();
				}
				url = "WEB-INF/index.jsp";		        
			}
			RequestDispatcher requestDispatcher = request.getRequestDispatcher(url);
			requestDispatcher.forward(request, response);
		}
		if(request.getParameter("getitemimage")!=null){
			String imagename=request.getParameter("getitemimage");
			response.getOutputStream().write(JcbDAO.getimage(imagename));
		}
		if(request.getParameter("tx") != null){
			HttpSession session = request.getSession();
			String transactionID = request.getParameter("tx");
			String paymentStatus = request.getParameter("st");
			String paymentAmount = request.getParameter("amt");
			String currency = request.getParameter("cc");
			String id = session.getAttribute("id").toString();
			session.setAttribute("transactionID", request.getParameter("tx"));
			session.setAttribute("paymentStatus", request.getParameter("st"));
			session.setAttribute("paymentAmount", request.getParameter("amt"));
			String s = JcbDAO.savePaymentDetails(transactionID,paymentStatus,paymentAmount,id,currency);
			if(s.equals("success")){				
				int row = JcbDAO.fetchCartSize(id);
				int paymantId = JcbDAO.getPaymentId(id, transactionID);				
				String address = "";
				ArrayList<Address> al = (ArrayList<Address>) JcbDAO.fetchAddressByAddID((String) session.getAttribute("addid"));
				Iterator<Address> it = al.iterator();
				while (it.hasNext()) {
					Address addressl = (Address) it.next();
					address = addressl.getAddressline1()+" "+addressl.getAddressline2()+" "+
							addressl.getCity()+" "+addressl.getState()+" "+addressl.getPin();
				}

				int finalOrderId = JcbDAO.saveFinalOrderAfterPayment(id,row,paymentAmount,address,paymantId);
				session.setAttribute("finalOrderId", finalOrderId);
				if(finalOrderId != 0){
					boolean status = JcbDAO.changeOrderStatus(id,finalOrderId,transactionID);
					if(status){
						session.removeAttribute("finalcart");
						response.sendRedirect("JCBController?action=success");							
					}				
				}				
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		logger.info("");
		if (request.getParameter("loginpno") != null) {
			logger.info("Validating User Credentials...");
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			JSONObject jobj=new JSONObject();
			HttpSession ses = request.getSession();
			ses.setAttribute("id", request.getParameter("loginpno"));
			String id = request.getParameter("loginpno");
			String pwd = request.getParameter("pwd");
			String referal = request.getParameter("referal");
			ses.setAttribute("referal", referal);
			int count = 0;
			if (!id.isEmpty() && id.matches("^[0-9]+")) {
				count++;
				if (!pwd.isEmpty()) {
					count++;
				}
			}else{
				jobj.put("loginstatus", "ID must contain only digits...");
			}
			String status = "";
			if (count == 2) {
				status = JcbDAO.loginValidate(id, pwd);
				ses.setAttribute("role", status);
				if (status.equalsIgnoreCase("customer")) {	
					jobj.put("loginstatus", "customer");
				} else if (status.equalsIgnoreCase("admin")) {
					jobj.put("loginstatus", "admin");
				} else if (status.equalsIgnoreCase("deliveryboy")) {
					jobj.put("loginstatus", "deliveryboy");
				}
				else if(status.equalsIgnoreCase("Invalid")){
					jobj.put("loginstatus", "Invalid Credentials...");
				}
			}
			logger.info(jobj.toJSONString());
			response.getWriter().write(jobj.toJSONString());
		}
		
		
		if(request.getParameter("removekey")!=null){
			HttpSession ses = request.getSession();
			String key = request.getParameter("removekey");
			TempCart finalCart = (TempCart)ses.getAttribute("finalcart");
			String id = ses.getAttribute("id").toString();
			if(!key.isEmpty()){
				if(finalCart != null){
					finalCart.remove(key); 					
				}
				JcbDAO.removeTempCart(key,id);
			}
		}
		if(request.getParameter("deleteitemname")!=null){
			HttpSession ses = request.getSession(false);
			if(ses != null){
				ses.removeAttribute("cart");
			}
		}
		if(request.getParameter("itemName")!=null){
			Item item = new Item();
			item.setItemName(request.getParameter("itemName"));
			item.setItemPrice(request.getParameter("price"));
			item.setItemDesc(request.getParameter("desc"));
			item.setItemTax(request.getParameter("tax"));
			item.setItemGroup(request.getParameter("group"));
			item.setItemImage(request.getPart("image"));
			int row = JcbDAO.saveNewItem(item);
			if(row != 0){                
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("WEB-INF/adminhome.jsp");
				requestDispatcher.forward(request, response);
			}
		}
		
		/// dont change/////////////
		if(request.getParameter("reguname") != null){
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			JSONObject jobj=new JSONObject();
			String uname = request.getParameter("reguname");
			String mailid = request.getParameter("mailid");            
			String phno = request.getParameter("mobile");
			String password = request.getParameter("password");
			String gender = request.getParameter("gender");
			String addressline1 = request.getParameter("addressline1");
			String addressline2 = request.getParameter("addressline2");
			String city = request.getParameter("city");
			String state = request.getParameter("state");
			String pin = request.getParameter("pin");
			int count = 0;
			String status = "";

			if(!uname.isEmpty() && uname.matches("[a-zA-Z ]+")){
				if(uname.matches("^.{2,50}$")){
					count++;				
					if(!mailid.isEmpty() && mailid.matches("^([A-Za-z0-9_\\-\\.])+\\@([A-Za-z0-9_\\-\\.])+\\.([A-Za-z]{2,4})$")){
						count++;
						if(!phno.isEmpty() && phno.matches("^[0-9]{10}$")){
							count++;
							if(!password.isEmpty()){
								if(password.matches("^.{4,8}$")){
									if(password.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{4,8}$")){
										count++;
										if(!(gender == null)){
											count++;
											if(!addressline1.isEmpty()){
												if(addressline1.matches("[a-zA-Z0-9-,:. ]+")){
													count++;
													if(!addressline2.isEmpty()){
														if(addressline2.matches("[a-zA-Z0-9-,:. ]+")){
															count++;
															if(!city.isEmpty()){
																if(city.matches("[a-zA-Z0-9-,:. ]+")){
																	count++;
																	if(!state.isEmpty()){
																		if(state.matches("[a-zA-Z0-9-,:. ]+")){
																			count++;
																			if(!pin.isEmpty()){
																				if(pin.matches("^[0-9]{5}$")){
																					count++;
																				}else{
																					jobj.put("regstatus", "Pincode must contain 5 digits...");
																				}
																			}else{
																				jobj.put("regstatus", "Pincode can't be empty...");
																			}
																		}else{
																			jobj.put("regstatus", "State can include ,.-: only...");
																		}
																	}else{
																		jobj.put("regstatus", "State Can't be empty...");
																	}
																}else{
																	jobj.put("regstatus", "City can include ,.-: only...");
																}
															}else{
																jobj.put("regstatus", "City can't be empty...");
															}
														}else{
															jobj.put("regstatus", "Address Line2 can include ,.-: only...");
														}
													}else{
														jobj.put("regstatus", "Address Line2 can't be empty...");
													}
												}else{
													jobj.put("regstatus", "Address Line1 can include ,.-: only...");
												}
											}else{
												jobj.put("regstatus", "Address Line1 can't be empty");
											}
										}else{
											jobj.put("regstatus", "You must select a gender...");
										}
									}else{
										jobj.put("regstatus", "Password must include at least one upper case letter, one lower case letter, and one numeric digit...");
									}
								}else{
									jobj.put("regstatus", "Password must contain Min 4 Charcter and Max 8");
								}
							}else{
								jobj.put("regstatus", "Password field can't be empty...");
							}
						}else{
							jobj.put("regstatus", "Invalid Mobile No. It must contain 10 digits");
						}
					}else{
						jobj.put("regstatus", "Invalid MailID.");
					}
				}else{
					jobj.put("regstatus", "It must contain greater than or equal to two characters...");
				}
			}else{
				jobj.put("regstatus", "Invalid User Name. It must have only characters...");
			}
			if(count == 10){
				Customer customer = new Customer();
				customer.setUname(uname);
				customer.setMailid(mailid);
				customer.setPhno(phno);
				customer.setPassword(password);
				customer.setGender(gender);

				Address address = new Address();
				address.setAddressline1(addressline1);
				address.setAddressline2(addressline2);
				address.setCity(city);
				address.setState(state);
				address.setPin(pin);
				address.setUserid(phno);

				status = JcbDAO.registerCustomer(customer,address);
				jobj.put("regstatus", status);				
			}
			response.getWriter().write(jobj.toJSONString());
		}
		if(request.getParameter("newaddressline1") != null){
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			JSONObject jobj=new JSONObject();
			String addressline1 = request.getParameter("newaddressline1");
			String addressline2 = request.getParameter("addressline2");
			String city = request.getParameter("city");
			String state = request.getParameter("state");
			String pin = request.getParameter("pincode");

			int count = 0;

			if(!addressline1.isEmpty()){
				if(addressline1.matches("[a-zA-Z0-9-,:. ]+")){
					count++;
					if(!addressline2.isEmpty()){
						if(addressline2.matches("[a-zA-Z0-9-,:. ]+")){
							count++;
							if(!city.isEmpty()){
								if(city.matches("[a-zA-Z0-9-,:. ]+")){
									count++;
									if(!state.isEmpty()){
										if(state.matches("[a-zA-Z0-9-,:. ]+")){
											count++;
											if(!pin.isEmpty()){
												if(pin.matches("^[0-9]{5}$")){
													count++;
												}else{
													jobj.put("addstatus", "Pincode must contain 5 digits...");
												}
											}else{
												jobj.put("addstatus", "Pincode can't be empty...");
											}
										}else{
											jobj.put("addstatus", "State can include ,.-: only...");
										}
									}else{
										jobj.put("addstatus", "State Can't be empty...");
									}
								}else{
									jobj.put("addstatus", "City can include ,.-: only...");
								}
							}else{
								jobj.put("addstatus", "City can't be empty...");
							}
						}else{
							jobj.put("addstatus", "Address Line2 can include ,.-: only...");
						}
					}else{
						jobj.put("addstatus", "Address Line2 can't be empty...");
					}
				}else{
					jobj.put("addstatus", "Address Line1 can include ,.-: only...");
				}
			}else{
				jobj.put("addstatus", "Address Line1 can't be empty");
			}

			HttpSession ses = request.getSession();
			if(count == 5){

				Address address = new Address();
				address.setAddressline1(addressline1);
				address.setAddressline2(addressline2);
				address.setCity(city);
				address.setState(state);
				address.setPin(pin);
				address.setUserid((String)ses.getAttribute("id"));

				String status = JcbDAO.registerAddress(address);
				jobj.put("addstatus", status);				
			}
			response.getWriter().write(jobj.toJSONString());
		}
		if(request.getParameter("eaddressline1") != null){
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			JSONObject jobj=new JSONObject();
			String addressline1 = request.getParameter("eaddressline1");
			String addressline2 = request.getParameter("eaddressline2");
			String city = request.getParameter("ecity");
			String state = request.getParameter("estate");
			String pin = request.getParameter("epincode");
			String addid = request.getParameter("eaddid");
			System.out.println(addid);  
			int count = 0;

			if(!addressline1.isEmpty()){
				if(addressline1.matches("[a-zA-Z0-9-,:. ]+")){
					count++;
					if(!addressline2.isEmpty()){
						if(addressline2.matches("[a-zA-Z0-9-,:. ]+")){
							count++;
							if(!city.isEmpty()){
								if(city.matches("[a-zA-Z0-9-,:. ]+")){
									count++;
									if(!state.isEmpty()){
										if(state.matches("[a-zA-Z0-9-,:. ]+")){
											count++;
											if(!pin.isEmpty()){
												if(pin.matches("^[0-9]{5}$")){
													count++;
												}else{
													jobj.put("addstatus", "Pincode must contain 5 digits...");
												}
											}else{
												jobj.put("addstatus", "Pincode can't be empty...");
											}
										}else{
											jobj.put("addstatus", "State can include ,.-: only...");
										}
									}else{
										jobj.put("addstatus", "State Can't be empty...");
									}
								}else{
									jobj.put("addstatus", "City can include ,.-: only...");
								}
							}else{
								jobj.put("addstatus", "City can't be empty...");
							}
						}else{
							jobj.put("addstatus", "Address Line2 can include ,.-: only...");
						}
					}else{
						jobj.put("addstatus", "Address Line2 can't be empty...");
					}
				}else{
					jobj.put("addstatus", "Address Line1 can include ,.-: only...");
				}
			}else{
				jobj.put("addstatus", "Address Line1 can't be empty");
			}
			if(count == 5){
				Address address = new Address();
				address.setAddressline1(addressline1);
				address.setAddressline2(addressline2);
				address.setCity(city);
				address.setState(state);
				address.setPin(pin);

				String status = JcbDAO.updateAddress(address,addid);
				jobj.put("addstatus", status);				
			}
			response.getWriter().write(jobj.toJSONString());
		}
		//////////////////dont change////////////////////////////////////
		
		
		///////////////////////////////////////////////////////////////////////
		
		
		if(request.getParameter("deleteaddid") != null){
			String addid = request.getParameter("deleteaddid");
			String i = JcbDAO.deleteAddressByID(addid);
			if(i.contains("Successfully")){
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("WEB-INF/SelectDeliveryPoint.jsp");
				requestDispatcher.forward(request, response);
			}
		}
		if(request.getParameter("setaddidinsession") != null){
			String addid = request.getParameter("setaddidinsession");
			HttpSession ses = request.getSession();
			ses.setAttribute("addid", addid);
		}
		if(request.getParameter("quantity")!=null){
			logger.info("Servlet Called...");
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			JSONObject jobj=new JSONObject();
			
			String itemName = request.getParameter("name");
			String itemPrice = request.getParameter("price");
			String itemQuantity = request.getParameter("quantity");
			double result = Double.parseDouble(request.getParameter("totalPrice"));
			String  totalPrice = String.format("%.2f", result);
			HttpSession ses = request.getSession();
			logger.info(itemName+" "+itemPrice+" "+itemQuantity+" "+totalPrice);
			
			FinalCart finalCart = new FinalCart();
			finalCart.setName(itemName);
			finalCart.setPrice(itemPrice);
			finalCart.setQuantity(itemQuantity);
			finalCart.setTotalPrice(String.valueOf(totalPrice));
			
			TempCart shopingCart = (TempCart)ses.getAttribute("finalcart");
			if(shopingCart == null){
				shopingCart = new TempCart();
			}
			
			shopingCart.addToCart(request.getParameter("name"), finalCart);        
			ses.setAttribute("finalcart", shopingCart);
			JcbDAO.saveTempCart(itemName,itemPrice,itemQuantity,totalPrice,ses.getAttribute("id").toString());
			jobj.put("cartValue", JcbDAO.fetchCartSize(ses.getAttribute("id").toString()));
			logger.info(jobj.toJSONString());
			response.getWriter().write(jobj.toJSONString());

		}
//		if(request.getParameter("tempitem")!=null){
//			response.setContentType("application/json");
//			response.setCharacterEncoding("UTF-8");
//			JSONObject jobj=new JSONObject();
//			HttpSession session = request.getSession();
//			TempCart cart1 = (TempCart) session.getAttribute("finalcart");
//			String status = null;
//			if (cart1 != null) {
//				HashMap<String, FinalCart> items = cart1.getCartItems();
//				for (String key : items.keySet()) {
//					FinalCart finalcart = items.get(key);
//				}
//			}
//			jobj.put("status", status);
//			response.getWriter().write(jobj.toJSONString());
//		}
		if(request.getParameter("currentPwd")!=null){
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			JSONObject jobj=new JSONObject();
			HttpSession session = request.getSession();
			String id = session.getAttribute("id").toString();
			String currentPwd = request.getParameter("currentPwd");
			String newPwd = request.getParameter("newPwd");
			String confPwd = request.getParameter("confPwd");
			int count = 0;
			if(!newPwd.isEmpty()){
				if(newPwd.matches("^.{4,8}$")){
					if(newPwd.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{4,8}$")){
						count++;
						if(!confPwd.isEmpty()){
							if(confPwd.matches("^.{4,8}$")){
								if(confPwd.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{4,8}$")){
									count++;
								}else{
									jobj.put("changePwd", "Confirm Password must include at least one upper case letter, one lower case letter, and one numeric digit...");
								}
							}else{
								jobj.put("changePwd", "Confirm Password must contain Min 4 Charcter and Max 8");
							}
						}else{
							jobj.put("changePwd", "Confirm Password field can't be empty...");
						}					
					}else{
						jobj.put("changePwd", "New Password must include at least one upper case letter, one lower case letter, and one numeric digit...");
					}
				}else{
					jobj.put("changePwd", "New Password must contain Min 4 Charcter and Max 8");
				}
			}else{
				jobj.put("changePwd", "New Password field can't be empty...");
			}
			if(count == 2){
				if(newPwd.equals(confPwd)){
					String status = JcbDAO.changePwd(id,currentPwd,newPwd);
					jobj.put("changePwd", status);				
				}else{
					jobj.put("changePwd", "Password Not Matched");  
				}
			}
			response.getWriter().write(jobj.toJSONString());
		}
		if(request.getParameter("emailVal")!=null){
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			JSONObject jobj=new JSONObject();
			HttpSession session = request.getSession();
			String id = session.getAttribute("id").toString();
			String mailid = request.getParameter("emailVal");
			if(!mailid.isEmpty() && mailid.matches("^([A-Za-z0-9_\\-\\.])+\\@([A-Za-z0-9_\\-\\.])+\\.([A-Za-z]{2,4})$")){
				String status = JcbDAO.updateCustomerEmailByID(id,mailid);
				jobj.put("updateEmail", status);
			}else{
				jobj.put("updateEmail", "Invalid MailID.");
			}
			response.getWriter().write(jobj.toJSONString());
		}    
		if(request.getParameter("phoneVal")!=null){
			response.setContentType("application/json");  
			response.setCharacterEncoding("UTF-8");
			JSONObject jobj=new JSONObject();  
			HttpSession session = request.getSession();
			String id = session.getAttribute("id").toString();
			String phno = request.getParameter("phoneVal"); 
			if(!phno.isEmpty() && phno.matches("^[0-9]{10}$")){
				String status = JcbDAO.updateCustomerPhoneNoByID(id,phno);
				if(status.contains("Successfully")){
					session.setAttribute("id", phno);  
				}
				jobj.put("updatePhNo", status);
			}else{
				jobj.put("updatePhNo", "Invalid Mobile No. It must contain 10 digits");
			}
			response.getWriter().write(jobj.toJSONString());
		}

		if(request.getParameter("editaddid")!=null){
			response.setContentType("application/json");  
			response.setCharacterEncoding("UTF-8");
			String addid = request.getParameter("editaddid");
			JSONObject addobj = JcbDAO.getAddressByID(addid);
			response.getWriter().write(addobj.toJSONString());
		}
		if(request.getParameter("forgotpno")!=null){
			response.setContentType("application/json");  
			response.setCharacterEncoding("UTF-8");
			JSONObject jobj=new JSONObject(); 
			String forgotpno = request.getParameter("forgotpno"); 
			if(!forgotpno.isEmpty() && forgotpno.matches("^[0-9]{10}$")){
				String status = JcbDAO.sendOTP(forgotpno);
				jobj.put("forgotstatus", status);
			}else{
				jobj.put("forgotstatus", "Invalid Mobile No. It must contain 10 digits");
			}
			logger.info("forgotpno :"+jobj.toJSONString());
			response.getWriter().write(jobj.toJSONString());
		}
		if(request.getParameter("otp")!=null){
			response.setContentType("application/json");  
			response.setCharacterEncoding("UTF-8");
			JSONObject jobj=new JSONObject(); 
			String otp = request.getParameter("otp"); 
			if(!otp.isEmpty() && otp.matches("^[0-9]{6}$")){
				String status = JcbDAO.validateOTP(otp);
				jobj.put("otpstatus", status);
			}else{
				jobj.put("otpstatus", "Invalid OTP. It must contain 6 digits");
			}
			logger.info("otpstatus :"+jobj.toJSONString());
			response.getWriter().write(jobj.toJSONString());
		}
		if(request.getParameter("enterotp")!=null){
			response.setContentType("application/json");  
			response.setCharacterEncoding("UTF-8");
			JSONObject jobj=new JSONObject(); 
			String otp = request.getParameter("enterotp"); 
			String newPwd =  request.getParameter("otpnew");
			String confPwd = request.getParameter("otpconf");
			int count = 0;
			if(!newPwd.isEmpty()){
				if(newPwd.matches("^.{4,8}$")){
					if(newPwd.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{4,8}$")){
						count++;
						if(!confPwd.isEmpty()){
							if(confPwd.matches("^.{4,8}$")){
								if(confPwd.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{4,8}$")){
									count++;
								}else{
									jobj.put("changeotpstatus", "Confirm Password must include at least one upper case letter, one lower case letter, and one numeric digit...");
								}
							}else{
								jobj.put("changeotpstatus", "Confirm Password must contain Min 4 Charcter and Max 8");
							}
						}else{
							jobj.put("changeotpstatus", "Confirm Password field can't be empty...");
						}					
					}else{
						jobj.put("changeotpstatus", "New Password must include at least one upper case letter, one lower case letter, and one numeric digit...");
					}
				}else{
					jobj.put("changeotpstatus", "New Password must contain Min 4 Charcter and Max 8");
				}
			}else{
				jobj.put("changeotpstatus", "New Password field can't be empty...");
			}
			if(count == 2){
				if(newPwd.equals(confPwd)){
					String status = JcbDAO.changePwdWithOTP(otp,newPwd);
					jobj.put("changeotpstatus", status);				
				}else{
					jobj.put("changeotpstatus", "Password Not Matched");  
				}
			}
			logger.info("changeotpstatus :"+jobj.toJSONString());
			response.getWriter().write(jobj.toJSONString());
		}
	}
}
