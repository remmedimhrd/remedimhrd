package com.jcb.bean;

public class Address {	
	
	private String addressId;
    private String addressline1;
    private String addressline2;
    private String city;
    private String state;
    private String pin;
    private String userid;
    
    
    public String getAddressId() {
		return addressId;
	}

	public void setAddressId(String addressId) {
		this.addressId = addressId;
	}

	public String getAddressline1() {
        return addressline1;
    }

    public void setAddressline1(String addressline1) {
        this.addressline1 = addressline1;
    }

    public String getAddressline2() {
        return addressline2;
    }

    public void setAddressline2(String addressline2) {
        this.addressline2 = addressline2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	@Override
	public String toString() {
		return "Address [addressline1=" + addressline1 + ", addressline2="
				+ addressline2 + ", city=" + city + ", state=" + state
				+ ", pin=" + pin + ", userid=" + userid + "]";
	}
}
