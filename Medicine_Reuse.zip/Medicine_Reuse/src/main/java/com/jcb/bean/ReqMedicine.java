package com.jcb.bean;

public class ReqMedicine {
	 private int id;
	    private String userName;
	    private String medicinebrandName;
	    private String medicinegenName;
	    private int quantity;
	    private String phoneNum;
	    public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public String getMedicinebrandName() {
			return medicinebrandName;
		}
		public void setMedicinebrandName(String medicinebrandName) {
			this.medicinebrandName = medicinebrandName;
		}
		public String getMedicinegenName() {
			return medicinegenName;
		}
		public void setMedicinegenName(String medicinegenName) {
			this.medicinegenName = medicinegenName;
		}
		public int getQuantity() {
			return quantity;
		}
		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		public String getPhoneNum() {
			return phoneNum;
		}
		public void setPhoneNum(String phoneNum) {
			this.phoneNum = phoneNum;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		private String address;

}
