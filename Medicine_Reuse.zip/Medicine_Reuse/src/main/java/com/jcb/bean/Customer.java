package com.jcb.bean;

public class Customer {

    private String uname;
    private String mailid;
    private String phno;
    private String password;
    private String gender;


    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getMailid() {
        return mailid;
    }

    public void setMailid(String mailid) {
        this.mailid = mailid;
    }

    public String getPhno() {
        return phno;
    }

    public void setPhno(String phno) {
        this.phno = phno;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

	@Override
	public String toString() {
		return "Customer [uname=" + uname + ", mailid=" + mailid + ", phno="
				+ phno + ", password=" + password + ", gender=" + gender + "]";
	}
    
    
}
