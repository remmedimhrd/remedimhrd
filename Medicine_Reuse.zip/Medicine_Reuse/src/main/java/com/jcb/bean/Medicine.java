package com.jcb.bean;

public class Medicine {
    private int id;
    private String medicineName;
    private String medicineGenName;
    private String manDate;
    private String expiryDate;
    private int quantity;
    private String fileName;

    // Getter and setter for id
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    // Getter and setter for medicineName
    public String getMedicineName() {
        return medicineName;
    }

    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }

    // Getter and setter for medicineGenName
    public String getMedicineGenName() {
        return medicineGenName;
    }

    public void setMedicineGenName(String medicineGenName) {
        this.medicineGenName = medicineGenName;
    }

    // Getter and setter for manDate
    public String getManDate() {
        return manDate;
    }

    public void setManDate(String manDate) {
        this.manDate = manDate;
    }

    // Getter and setter for expiryDate
    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    // Getter and setter for quantity
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Getter and setter for fileName
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}
