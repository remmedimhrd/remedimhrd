package com.jcb.bean;

import javax.servlet.http.Part;

public class Item {
    private String itemName;
    private String itemPrice;
    private String itemDesc;
    private String itemTax;
    private String itemGroup;
    private String itemSubGroup;
    private Part itemImage;

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(String itemPrice) {
        this.itemPrice = itemPrice;
    }

    public String getItemDesc() {
        return itemDesc;
    }

    public void setItemDesc(String itemDesc) {
        this.itemDesc = itemDesc;
    }

    public String getItemTax() {
        return itemTax;
    }

    public void setItemTax(String itemTax) {
        this.itemTax = itemTax;
    }

    public String getItemGroup() {
        return itemGroup;
    }

    public void setItemGroup(String itemGroup) {
        this.itemGroup = itemGroup;
    }

    public String getItemSubGroup() {
        return itemSubGroup;
    }

    public void setItemSubGroup(String itemSubGroup) {
        this.itemSubGroup = itemSubGroup;
    }    

    public Part getItemImage() {
        return itemImage;
    }

    public void setItemImage(Part itemImage) {
        this.itemImage = itemImage;
    }

    @Override
    public String toString() {
        return "Item{" + "itemName=" + itemName + ", itemPrice=" + itemPrice + ", itemDesc=" + itemDesc + ", itemTax=" + itemTax + ", itemGroup=" + itemGroup + '}';
    }
    
}
