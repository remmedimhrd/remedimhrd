package com.jcb.bean;

import java.util.HashMap;

public class TempCart {
HashMap<String, FinalCart> cartItems;
    
    public TempCart(){
        cartItems = new HashMap<String, FinalCart>();      
    }   
    public HashMap<String,FinalCart> getCartItems(){
        return cartItems;
    }
    public void addToCart(String itemId, FinalCart finalCart){
        cartItems.put(itemId, finalCart);
    }
	public void remove(String key) {
		cartItems.remove(key);
	}
}
