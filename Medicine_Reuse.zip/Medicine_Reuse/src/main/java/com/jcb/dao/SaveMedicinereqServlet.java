
package com.jcb.dao;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/SaveMedicinereqServlet")
@MultipartConfig
public class SaveMedicinereqServlet extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter("userName");
        String brandName = request.getParameter("brandName");
        String genericName = request.getParameter("genericName");
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        String phoneNumber = request.getParameter("phoneNumber");
        String deliveryAddress = request.getParameter("deliveryAddress");


       
        // Save data to the database
        saveToDatabase(userName, brandName, genericName, quantity, phoneNumber, deliveryAddress);
        
        request.setAttribute("successMessage", "Medicine uploaded successfully!");
        
     // Forward to index.jsp with success message
        RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/Request_Medicine.jsp");
        dispatcher.forward(request, response);
        
         // Redirect back to the form page
    }

   
    

    private void saveToDatabase(String userName, String brandName, String genericName, int quantity, String phoneNumber, String deliveryAddress) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Load JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Connect to the database (replace with your actual database credentials and connection URL)
            String url = "jdbc:mysql://localhost:3306/jcbpoint?autoReconnect=true&useSSL=false";
            String username = "root";
            String password = "P@ssw0rd2143";
            conn = DriverManager.getConnection(url, username, password);

            // Insert data into the database
            String sql = "INSERT INTO requests (userName , brandName , genericName , quantity , phoneNumber , deliveryAddress ) VALUES (?, ?, ?, ?, ?, ?)";
            System.out.println("SQL Query: " + sql);
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, userName);
            pstmt.setString(2, brandName);
            pstmt.setString(3, genericName);
            pstmt.setInt(4, quantity);
            pstmt.setString(5, phoneNumber);
            pstmt.setString(6, deliveryAddress);

            pstmt.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
