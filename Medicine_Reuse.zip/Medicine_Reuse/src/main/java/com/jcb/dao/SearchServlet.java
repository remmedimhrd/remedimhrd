package com.jcb.dao;



import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jcb.bean.Medicine;

@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String brandName = request.getParameter("medicineName");
        String genericName = request.getParameter("medicineGenName");

        MedicineDAO medicineDAO = new MedicineDAO();
        List<Medicine> medicines;

        if (brandName != null && genericName != null) {
            medicines = medicineDAO.searchMedicines(brandName, genericName);
        } else {
            medicines = medicineDAO.getAllMedicines();
        }

        request.setAttribute("medicines", medicines);
        request.getRequestDispatcher("searchItems.jsp").forward(request, response);
    }
}