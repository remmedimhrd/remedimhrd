package com.jcb.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jcb.bean.Medicine;
import com.jcb.utility.JdbcUtility;

public class MedicineDAO {
    public List<Medicine> getAllMedicines() {
        List<Medicine> medicines = new ArrayList<>();
        String query = "SELECT * FROM medicines";

        try (Connection connection = JdbcUtility.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                Medicine medicine = new Medicine();
                medicine.setId(resultSet.getInt("id"));
                medicine.setMedicineName(resultSet.getString("medicineName"));
                medicine.setMedicineGenName(resultSet.getString("medicineGenName"));
                medicine.setManDate(resultSet.getString("manDate"));
                medicine.setExpiryDate(resultSet.getString("expiryDate"));
                medicine.setQuantity(resultSet.getInt("quantity"));
                medicine.setFileName(resultSet.getString("fileName"));

                medicines.add(medicine);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return medicines;
    }
    
 // Your database connection code and other methods...

    // Search medicines based on brand name and generic name
    public List<Medicine> searchMedicines(String medicineName, String medicineGenName) {
        List<Medicine> medicines = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = JdbcUtility.getConnection();

            String sql = "SELECT * FROM medicines WHERE medicineName=? AND medicineGenName=?";
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1, "%" + medicineName + "%");
            preparedStatement.setString(2, "%" + medicineGenName + "%");

            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
            	  Medicine medicine = new Medicine();
                  medicine.setId(resultSet.getInt("id"));
                  medicine.setMedicineName(resultSet.getString("medicineName"));
                  medicine.setMedicineGenName(resultSet.getString("medicineGenName"));
                  medicine.setManDate(resultSet.getString("manDate"));
                  medicine.setExpiryDate(resultSet.getString("expiryDate"));
                  medicine.setQuantity(resultSet.getInt("quantity"));
                  medicine.setFileName(resultSet.getString("fileName"));


                // Add other setters as needed

                medicines.add(medicine);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JdbcUtility.rsClose(resultSet);
            JdbcUtility.pstClose(preparedStatement);
            JdbcUtility.conClose(connection);
        }

        return medicines;
    }
    public void deleteMedicineById(int medicineId) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = JdbcUtility.getConnection();
            String query = "DELETE FROM medicines WHERE id = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, medicineId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception appropriately
        } finally {
            JdbcUtility.pstClose(preparedStatement);
            JdbcUtility.conClose(connection);
        }
    }
}



