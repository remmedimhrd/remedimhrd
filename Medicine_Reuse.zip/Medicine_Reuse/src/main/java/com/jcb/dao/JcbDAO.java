package com.jcb.dao;

import com.jcb.bean.Address;
import com.jcb.bean.AdmAddress;
import com.jcb.bean.Admin;
import com.jcb.bean.Customer;
import com.jcb.bean.FinalCart;
import com.jcb.bean.Item;
import com.jcb.mail.Mail;
import com.jcb.utility.JdbcUtility;

import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.servlet.http.Part;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

public class JcbDAO {

	public static final String SALT = "just_curry_box";
	final static Logger logger = Logger.getLogger(JcbDAO.class);
	
	private static String generateHash(String password) {
		StringBuilder hash = new StringBuilder();

		try {
			MessageDigest sha = MessageDigest.getInstance("SHA-1");
			byte[] hashedBytes = sha.digest(password.getBytes());
			char[] digits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
					'a', 'b', 'c', 'd', 'e', 'f' };
			for (int idx = 0; idx < hashedBytes.length; ++idx) {
				byte b = hashedBytes[idx];
				hash.append(digits[(b & 0xf0) >> 4]);
				hash.append(digits[b & 0x0f]);
			}
		} catch (NoSuchAlgorithmException e) {
			logger.error("generateHash Error :" +e);
		}

		return hash.toString();
	}
	
	private static char[] generateOTP(){
		String numbers = "123456789";
		Random r = new Random();
		char[] otp = new char[6];
		for(int i = 0;i<otp.length;i++){
			otp[i] = numbers.charAt(r.nextInt(numbers.length()));
		}
		return otp;
	}
	
	public static String loginValidate(String id, String pwd) {
		String hashedPwd = generateHash(SALT+pwd);
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		final String sql = "select userrole from jcb_user_login_db where userid = ? and password = ?";
		String status = "";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, id);
			pst.setString(2, hashedPwd);
			rs = pst.executeQuery();
			if (rs.next()) {
				status = rs.getString("userrole");
			}else{
				status = "Invalid";
			}
		} catch (SQLException e) {
			logger.error("loginValidate Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.rsClose(rs);
			JdbcUtility.pstClose(pst);
		}
		return status;
	}

	
	public static String admloginValidate(String id, String pwd) {
		String hashedPwd = generateHash(SALT+pwd);
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		final String sql = "select userrole from jcb_admin_login_db where userid = ? and password = ?";
		String status = "";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, id);
			pst.setString(2, hashedPwd);
			rs = pst.executeQuery();
			if (rs.next()) {
				status = rs.getString("userrole");
			}else{
				status = "Invalid";
			}
		} catch (SQLException e) {
			logger.error("loginValidate Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.rsClose(rs);
			JdbcUtility.pstClose(pst);
		}
		return status;
	}
	
	public static int saveNewItem(Item item) {
		Part image = item.getItemImage();
		InputStream inputStream = null;
		if (image != null) {
			try {
				inputStream = image.getInputStream();
			} catch (IOException e) {
				logger.error("Save New Item inputstream Error :" +e);
			}
		}
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		final String sql = "insert into jcb_admin_item_insertion_table(itemShortName,itemPrice,itemDescription,"
				+ "itemImage,itemTax,itemGroup) values(?,?,?,?,?,?)";
		int row = 0;
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, item.getItemName());
			pst.setString(2, item.getItemPrice());
			pst.setString(3, item.getItemDesc());
			pst.setBinaryStream(4, inputStream, (int) image.getSize());
			pst.setString(5, item.getItemTax());
			pst.setString(6, item.getItemGroup());
			row = pst.executeUpdate();
		} catch (SQLException e) {
			logger.error("saveNewItem Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.pstClose(pst);
		}
		return row;
	}

	public static List<Item> fetchItems(String itemGroup) {
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		ArrayList<Item> al = new ArrayList<Item>();
		final String sql = "select * from jcb_admin_item_insertion_table where itemGroup = ?";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, itemGroup);
			rs = pst.executeQuery();
			while (rs.next()) {
				Item item = new Item();
				item.setItemName(rs.getString("itemShortName"));
				item.setItemPrice(rs.getString("itemPrice"));
				item.setItemDesc(rs.getString("itemDescription"));
				al.add(item);
			}
		} catch (SQLException e) {
			logger.error("fetchItems Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.rsClose(rs);
			JdbcUtility.pstClose(pst);
		}
		return al;
	}

	public static String registerCustomer(Customer customer,Address address) {
		String hashedPwd = generateHash(SALT+customer.getPassword());
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		PreparedStatement pst1 = null;
		PreparedStatement pst2 = null;

		final String sql = "insert into jcb_user_account_table(userid,userName,phoneNumber,"
				+ "emailId,password,gender,status,createdTime) values(?,?,?,?,?,?,?,?)";

		final String sql2 = "insert into jcb_address_list_table(userid,addressLine1,addressLine2,city,state,pincode) values(?,?,?,?,?,?)";

		final String sql1 = "insert into jcb_user_login_db values(?,?,?)";

		String status = "";

		Timestamp datestamp = new Timestamp(new Date().getTime());
		try {
			pst = con.prepareStatement(sql);
			pst.setLong(1, Long.parseLong(customer.getPhno()));
			pst.setString(2, customer.getUname());
			pst.setString(3, customer.getPhno());
			pst.setString(4, customer.getMailid());
			pst.setString(5, hashedPwd);
			pst.setString(6, customer.getGender());
			pst.setString(7, "n");
			pst.setTimestamp(8, datestamp);

			int row = pst.executeUpdate();

			if(row!=0){
				pst1 = con.prepareStatement(sql1);
				pst1.setString(1, customer.getPhno());
				pst1.setString(2, hashedPwd);
				pst1.setString(3, "customer");
				pst1.executeUpdate();

				pst2 = con.prepareStatement(sql2);
				pst2.setString(1, address.getUserid());
				pst2.setString(2, address.getAddressline1());
				pst2.setString(3, address.getAddressline2());
				pst2.setString(4, address.getCity());
				pst2.setString(5, address.getState());
				pst2.setString(6, address.getPin());
				pst2.executeUpdate();

				status = "Successfully Registered...";
			}else{
				status = "Something Went Wrong...";
			}
		} catch (SQLException e) {
			logger.error("registerCustomer Error :" +e);
			if(e.getMessage().contains("Duplicate")){
				logger.error("registerCustomer Error :" +e);
				status = "Already Registered";
			}
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.pstClose(pst);
			JdbcUtility.pstClose(pst1);
			JdbcUtility.pstClose(pst2);
		}
		return status;

	}
	public static Customer getCustomerByID(String id){
		Customer customer = new Customer();
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		final String sql = "select * from jcb_user_account_table where userid = ?";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, id);
			rs = pst.executeQuery();
			while (rs.next()) {
				customer.setUname(rs.getString("userName"));
				customer.setMailid(rs.getString("emailId"));
				customer.setPhno(rs.getString("phoneNumber"));
			}
		} catch (SQLException e) {
			logger.error("getCustomerByID Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.rsClose(rs);
			JdbcUtility.pstClose(pst);
		}
		return customer;
	}

	public static List<Address> fetchAddressByID(String id){
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		ArrayList<Address> al = new ArrayList<Address>();
		final String sql = "select * from jcb_address_list_table where userid = ?";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, id);
			rs = pst.executeQuery();
			while (rs.next()) {
				Address address = new Address();
				address.setAddressId(rs.getString("addressId"));
				address.setAddressline1(rs.getString("addressLine1"));
				address.setAddressline2(rs.getString("addressLine2"));
				address.setState(rs.getString("state"));
				address.setCity(rs.getString("city"));
				address.setPin(rs.getString("pincode"));
				al.add(address);
			}
		} catch (SQLException e) {
			logger.error("fetchAddressByID Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.rsClose(rs);
			JdbcUtility.pstClose(pst);
		}
		return al;
	}

	public static List<Address> fetchAddressByAddID(String id){
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		ArrayList<Address> al = new ArrayList<Address>();
		final String sql = "select * from jcb_address_list_table where addressId = ?";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, id);
			rs = pst.executeQuery();
			while (rs.next()) {
				Address address = new Address();
				address.setAddressId(rs.getString("addressId"));
				address.setAddressline1(rs.getString("addressLine1"));
				address.setAddressline2(rs.getString("addressLine2"));
				address.setState(rs.getString("state"));
				address.setCity(rs.getString("city"));
				address.setPin(rs.getString("pincode"));
				al.add(address);
			}
		} catch (SQLException e) {
			logger.error("fetchAddressByAddID Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.rsClose(rs);
			JdbcUtility.pstClose(pst);
		}
		return al;
	}

	public static String registerAddress(Address address) {
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;

		final String sql = "insert into jcb_address_list_table(userid,addressLine1,addressLine2,city,state,pincode) values(?,?,?,?,?,?)";

		String status = "";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, address.getUserid());
			pst.setString(2, address.getAddressline1());
			pst.setString(3, address.getAddressline2());
			pst.setString(4, address.getCity());
			pst.setString(5, address.getState());
			pst.setString(6, address.getPin());
			int row = pst.executeUpdate();

			if(row!=0){
				status = "Successfully Registered...";
			}else{
				status = "Something Went Wrong...";
			}
		} catch (SQLException e) {
			logger.error("registerAddress Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.pstClose(pst);
		}
		return status;
	}

	public static String deleteAddressByID(String addid) {
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;

		final String sql = "delete from jcb_address_list_table where addressId = ?";

		String status = "";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, addid);
			int row = pst.executeUpdate();

			if(row!=0){
				status = "Successfully Deleted...";
			}else{
				status = "Something Went Wrong...";
			}
		} catch (SQLException e) {
			logger.error("deleteAddressByID Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.pstClose(pst);
		}
		return status;
	}
	public static double getTax(String name){
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		double tax = 0;
		final String sql = "select itemTax from jcb_admin_item_insertion_table where itemShortName = ?";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, name);
			rs = pst.executeQuery();
			while (rs.next()) {
				tax = rs.getDouble("itemTax");
			}
		} catch (SQLException e) {
			logger.error("getTax Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.rsClose(rs);
			JdbcUtility.pstClose(pst);
		}
		return tax;
	}
	public static byte[] getimage(String itemShortName){
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		byte[] image=null;
		final String sql = "select itemImage from jcb_admin_item_insertion_table where itemShortName = ? ";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, itemShortName);
			rs = pst.executeQuery();
			while (rs.next()) {            	
				image=rs.getBytes("itemImage");
			}
		} catch (SQLException e) {
			logger.error("getimage Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.rsClose(rs);
			JdbcUtility.pstClose(pst);
		}
		return image;    	
	}
	public static String getDeliveryCharge(String id, String referal){
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String deliveryChargeAmmount=null;
		if(referal.equalsIgnoreCase("Y")){
			final String sql1="select with_referal from jcb_referal_reward_table";
			try{
				pst = con.prepareStatement(sql1);
				rs = pst.executeQuery();
				while(rs.next()){
					deliveryChargeAmmount=rs.getString("with_referal");
				}
			}catch (SQLException e) {
				logger.error("getDeliveryCharge Error :" +e);
			}
		}else{
			final String sql1="select without_referal from jcb_referal_reward_table";
			try{
				pst=con.prepareStatement(sql1);
				rs = pst.executeQuery();
				while(rs.next()){
					deliveryChargeAmmount=rs.getString("without_referal");
				}
			}catch (SQLException e) {
				logger.error("getDeliveryCharge Error :" +e);
			}
		}
		JdbcUtility.conClose(con);
		JdbcUtility.rsClose(rs);
		JdbcUtility.pstClose(pst); 
		return deliveryChargeAmmount;
	}
	public static String removeTempCart(String itemName, String id) {
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		String status = null;
		final String sql = "delete from jcb_ordered_items_table where itemName = ? and userId = ? and orderStatus =?";
		try{			
			pst = con.prepareStatement(sql);
			pst.setString(1, itemName);	
			pst.setString(2, id);			
			pst.setString(3, "Temp");				
			int row = pst.executeUpdate();				
			if(row != 0){
				status = "success";
			}			
		}catch (SQLException e) {
			logger.error("removeTempCart Error :" +e);
		}finally{
			JdbcUtility.conClose(con);
			JdbcUtility.pstClose(pst); 
		}
		return status;
	}

	private static String getItemId(String name) {
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String itemId = "";
		final String sql = "select itemId from jcb_admin_item_insertion_table where itemShortName = ?";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, name);
			rs = pst.executeQuery();
			if (rs.next()) {
				itemId = rs.getString("itemId");
			}
		} catch (SQLException e) {
			logger.error("getItemId Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.rsClose(rs);
			JdbcUtility.pstClose(pst);
		}
		return itemId;
	}

	private static String getItemGroup(String name) {
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String group = "";
		final String sql = "select itemGroup from jcb_admin_item_insertion_table where itemShortName = ?";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, name);
			rs = pst.executeQuery();
			if (rs.next()) {
				group = rs.getString("itemGroup");
			}
		} catch (SQLException e) {
			logger.error("getItemGroup Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.rsClose(rs);
			JdbcUtility.pstClose(pst);
		}
		return group;
	}

	public static String changePwd(String id, String currentPwd, String newPwd) {
		String hashedCrntPwd = generateHash(SALT+currentPwd);
		String hashedNewPwd = generateHash(SALT+newPwd);
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		PreparedStatement pst1 = null;
		PreparedStatement pst2 = null;
		ResultSet rs = null;
		String status = "";
		final String sql = "select * from jcb_user_login_db where userid = ? and password = ?";
		final String sql1= "update jcb_user_login_db set password = ? where userid = ?";
		final String sql2 = "update jcb_user_account_table set password =? where userid = ?";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, id);
			pst.setString(2, hashedCrntPwd);
			rs = pst.executeQuery();
			if (rs.next()) {
				pst1 = con.prepareStatement(sql1);
				pst1.setString(1, hashedNewPwd);
				pst1.setString(2, id);
				int row = pst1.executeUpdate();
				pst2 = con.prepareStatement(sql2);
				pst2.setString(1, hashedNewPwd);
				pst2.setString(2, id);
				int row1 = pst2.executeUpdate();
				if(row != 0 && row1 != 0){
					status = "Password Successfully Updated...";
				}
			}else{
				status = "Invalid Current Password....";
			}
		} catch (SQLException e) {
			logger.error("changePwd Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.rsClose(rs);
			JdbcUtility.pstClose(pst);
			JdbcUtility.pstClose(pst1);
			JdbcUtility.pstClose(pst2);
		}
		return status;
	}

	public static String updateCustomerEmailByID(String id,String mail) {
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		String status = "";
		final String sql= "update jcb_user_account_table set emailId = ? where userid = ?";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, mail);
			pst.setString(2, id);
			int row = pst.executeUpdate();
			if (row != 0) {
				status = "Email Successfully Updated...";
			}else{
				status = "Invalid Password....";
			}
		} catch (SQLException e) {
			logger.error("updateCustomerEmailByID Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.pstClose(pst);
		}
		return status;
	}

	public static String updateCustomerPhoneNoByID(String id, String phno) {
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		PreparedStatement pst1 = null;
		PreparedStatement pst2 = null;
		PreparedStatement pst3 = null;
		String status = "";
		final String sql= "update jcb_user_account_table set userid = ?, phoneNumber = ?  where userid = ?";
		final String sql1 = "update jcb_address_list_table set userid = ? where userid = ?";
		final String sql2 = "update jcb_user_login_db set userid = ? where userid = ?";
		final String sql3 = "update jcb_ordered_items_table set userid = ? where userid = ?";
		try {
			pst = con.prepareStatement(sql);
			pst.setLong(1, Long.parseLong(phno));
			pst.setString(2, phno);
			pst.setString(3, id);
			int row = pst.executeUpdate();
			if (row != 0) {
				pst1 = con.prepareStatement(sql1);
				pst1.setString(1, phno);
				pst1.setString(2, id);
				row = pst1.executeUpdate();
				if (row != 0) {
					pst2 = con.prepareStatement(sql2);
					pst2.setString(1, phno);
					pst2.setString(2, id);
					row = pst2.executeUpdate();
					if (row != 0) {
						pst3 = con.prepareStatement(sql3);
						pst3.setString(1, phno);
						pst3.setString(2, id);
						pst3.executeUpdate();
						status = "Phone Number Successfully Updated...";
					}
				}
			}else{
				status = "Invalid Password....";
			}
		} catch (SQLException e) {
			logger.error("updateCustomerPhoneNoByID Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.pstClose(pst);
		}
		return status;
	}

	@SuppressWarnings("unchecked")
	public static JSONObject getAddressByID(String addid) {
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		JSONObject addobj = new JSONObject();
		final String sql = "select * from jcb_address_list_table where addressId = ?";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, addid);
			rs = pst.executeQuery();
			if (rs.next()) {
				addobj.put("addressLine1", rs.getString("addressLine1"));
				addobj.put("addressLine2", rs.getString("addressLine2"));
				addobj.put("city", rs.getString("city"));
				addobj.put("state", rs.getString("state"));
				addobj.put("pincode", rs.getString("pincode"));
			}
		} catch (SQLException e) {
			logger.error("getAddressByID Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.rsClose(rs);
			JdbcUtility.pstClose(pst);
		}	
		return addobj;
	}
	public static ArrayList<String> getItemName() {
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		ArrayList<String> al = new ArrayList<String>();
		final String sql = "SELECT itemShortName FROM jcb_admin_item_insertion_table ORDER BY itemId DESC LIMIT 10";
		try {
			pst = con.prepareStatement(sql);
			rs = pst.executeQuery();
			while (rs.next()) {
				al.add(rs.getString("itemShortName"));
			}
		} catch (SQLException e) {
			logger.error("getItemName Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.rsClose(rs);
			JdbcUtility.pstClose(pst);
		}	
		return al;
	}

	public static String updateAddress(Address address, String addid) {
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;

		final String sql = "update jcb_address_list_table set addressLine1 = ?, addressLine2 = ?, city = ?, state = ?, pincode = ? where addressId = ?";

		String status = "";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, address.getAddressline1());
			pst.setString(2, address.getAddressline2());
			pst.setString(3, address.getCity());
			pst.setString(4, address.getState());
			pst.setString(5, address.getPin());
			pst.setString(6, addid);
			int row = pst.executeUpdate();

			if(row!=0){
				status = "Successfully Updated...";
			}else{
				status = "Something Went Wrong...";
			}
		} catch (SQLException e) {
			logger.error("updateAddress Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.pstClose(pst);
		}
		return status;
	}

	public static String savePaymentDetails(String tx, String st, String amt, String id, String currency) {
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		final String sql = "insert into jcb_payment_details_table(userId,paypalPaymentId,create_time,amount,currency,created_at,payment_status) values(?,?,?,?,?,?,?)";
		String status = null;
		long time = System.currentTimeMillis();
		java.sql.Timestamp timestamp = new java.sql.Timestamp(time);
		Timestamp datestamp = new Timestamp(new Date().getTime());
		try{
			pst = con.prepareStatement(sql);
			pst.setString(1, id);
			pst.setString(2, tx);
			pst.setTimestamp(3, datestamp);
			pst.setString(4, amt);
			pst.setString(5, currency);
			pst.setTimestamp(6, timestamp);
			pst.setString(7, st);
			int row = pst.executeUpdate();
			if(row != 0){
				status = "success";
			}
		}catch(SQLException e){
			logger.error("savePaymentDetails Error :" +e);
			status = e.getMessage();
		}finally{
			JdbcUtility.conClose(con);
			JdbcUtility.pstClose(pst);
		}
		return status;
	}

	public static boolean changeOrderStatus(String id, int finalOrderId, String transactionId) {
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;

		final String sql = "update jcb_ordered_items_table set orderStatus = ?, orderIdClient =?,transactionId=? where userid = ? and orderStatus = ?";

		boolean status = false;
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, "Payment Done");
			pst.setString(2, ""+finalOrderId);
			pst.setString(3, transactionId);
			pst.setString(4, id);
			pst.setString(5, "Temp");
			int row = pst.executeUpdate();
			if(row!=0){
				status = true;
			}
		} catch (SQLException e) {
			logger.error("changeOrderStatus Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.pstClose(pst);
		}
		return status;
		
	}

	public static int saveFinalOrderAfterPayment(String id,int quantity,String amt,String address,int paymentid) {
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		PreparedStatement pst1 = null;
		ResultSet rs = null;
		final String sql = "insert into jcb_final_order_conformation_table(userId,orderDate,noOfItems,orderTotal,deliveryAddress,paymentId,status) values(?,?,?,?,?,?,?)";
		final String sql1 = "select orderId from jcb_final_order_conformation_table where userId = ? and paymentId = ?";
		int finalOrderId = 0;
		Timestamp datestamp = new Timestamp(new Date().getTime());
		try{
			pst = con.prepareStatement(sql);
			pst.setString(1, id);
			pst.setTimestamp(2, datestamp);
			pst.setInt(3, quantity);
			pst.setString(4, amt);
			pst.setString(5, address);
			pst.setInt(6, paymentid);
			pst.setString(7, "Paid");
			int row = pst.executeUpdate();
			if(row != 0){
				pst1 = con.prepareStatement(sql1);
				pst1.setString(1, id);
				pst1.setInt(2, paymentid);
				rs = pst1.executeQuery();
				if(rs.next()){
					finalOrderId = rs.getInt("orderId");
				}
			}
		}catch(SQLException e){
			logger.error("saveFinalOrderAfterPayment Error :" +e);
		}finally{
			JdbcUtility.conClose(con);
			JdbcUtility.pstClose(pst);
		}
		return finalOrderId;
		
	}

	public static int getPaymentId(String userId, String transactionId) {
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		final String sql = "select id from jcb_payment_details_table where userId = ? and paypalPaymentId = ?";
		try{
			pst = con.prepareStatement(sql);
			pst.setString(1, userId);
			pst.setString(2, transactionId);
			rs = pst.executeQuery();
			if(rs.next()){
				return rs.getInt("id");
			}
		}catch(SQLException e){
			logger.error("getPaymentId Error :" +e);
		}finally{
			JdbcUtility.conClose(con);
			JdbcUtility.pstClose(pst);
		}
		return 0;
	}

	public static void saveTempCart(String itemName, String itemPrice,
			String itemQuantity, String totalPrice, String id) {
		logger.info("DAO Called...");
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		PreparedStatement pst1 = null;
		PreparedStatement pst2 = null;
		ResultSet rs = null;
		final String sql = "select * from jcb_ordered_items_table where itemName =? and orderStatus= ?";
		final String sql1 = "update jcb_ordered_items_table set itemQuantity=?, itemTotal=? where itemName = ? and orderStatus = ?";
		final String sql2 = "insert into jcb_ordered_items_table(orderIdClient,itemId,itemName,itemPrice,itemQuantity,itemTax,"
				+ "itemGroup,itemTotal,userId,orderStatus) values(?,?,?,?,?,?,?,?,?,?)";
		String group = JcbDAO.getItemGroup(itemName);
		String itemId = JcbDAO.getItemId(itemName);
		try{
			pst = con.prepareStatement(sql);
			pst.setString(1, itemName);
			pst.setString(2, "Temp");
			rs = pst.executeQuery();
			if(rs.next()){
				logger.info("\"select * from jcb_ordered_items_table where itemName =? and orderStatus= ?\" Executed...");
				pst1 = con.prepareStatement(sql1);
				pst1.setString(1, itemQuantity);
				pst1.setString(2, totalPrice);
				pst1.setString(3, itemName);
				pst1.setString(4, "Temp");
				int i = pst1.executeUpdate();
				if(i!=0){
					logger.info("\"update jcb_ordered_items_table set itemQuantity=?, itemTotal=? where itemName = ? and orderStatus = ?\" Executed...");
				}
			}
			else{
				logger.info("\"insert into jcb_ordered_items_table(orderIdClient,itemId,itemName,itemPrice,itemQuantity,itemTax,"
				+ "itemGroup,itemTotal,userId,orderStatus) values(?,?,?,?,?,?,?,?,?,?)\" Executed...");
				pst2 = con.prepareStatement(sql2);
				pst2.setString(1, "");
				pst2.setString(2, itemId);
				pst2.setString(3, itemName);
				pst2.setString(4, itemPrice);
				pst2.setString(5, itemQuantity);
				pst2.setString(6, String.valueOf(JcbDAO.getTax(itemName)));
				pst2.setString(7, group);
				pst2.setString(8, totalPrice);
				pst2.setString(9, id);
				pst2.setString(10, "Temp");				
				pst2.executeUpdate();						
			}			
		}catch (SQLException e) {
			logger.error("Something Wrong :" +e);
		}finally{
			JdbcUtility.conClose(con);
			JdbcUtility.rsClose(rs);
			JdbcUtility.pstClose(pst); 
		}
	}
	public static ArrayList<FinalCart> fetchTempCart(String id){
		ArrayList<FinalCart> al = new ArrayList<FinalCart>();
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		final String sql = "select * from jcb_ordered_items_table where userId = ? and orderStatus = ?";
		try{
			pst = con.prepareStatement(sql);
			pst.setString(1, id);
			pst.setString(2, "Temp");
			rs = pst.executeQuery();
			while(rs.next()){
				FinalCart cart = new FinalCart();
				cart.setName(rs.getString("itemName"));
				cart.setPrice(rs.getString("itemPrice"));
				cart.setQuantity(rs.getString("itemQuantity"));
				cart.setTotalPrice(rs.getString("itemTotal"));
				al.add(cart);
			}
		}catch(SQLException e){
			logger.error("fetchTempCart Error :" +e);
		}finally{
			JdbcUtility.conClose(con);
			JdbcUtility.pstClose(pst);
		}
		return al;		
	}
	
	public static ArrayList<FinalCart> fetchFinalCart(String id){
		ArrayList<FinalCart> al = new ArrayList<FinalCart>();
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		final String sql = "select * from jcb_ordered_items_table where userId = ? and orderStatus = ?";
		try{
			pst = con.prepareStatement(sql);
			pst.setString(1, id);
			pst.setString(2, "Payment Done");
			rs = pst.executeQuery();
			while(rs.next()){
				FinalCart cart = new FinalCart();
				cart.setName(rs.getString("itemName"));
				cart.setQuantity(rs.getString("itemQuantity"));
				cart.setTotalPrice(rs.getString("itemTotal"));
				al.add(cart);
			}
		}catch(SQLException e){
			logger.error("fetchFinalCart Error :" +e);
		}finally{
			JdbcUtility.conClose(con);
			JdbcUtility.pstClose(pst);
		}
		return al;		
	}
	
	public static ArrayList<FinalCart> fetchFinalCartByTxnID(String id){
		ArrayList<FinalCart> al = new ArrayList<FinalCart>();
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		final String sql = "select * from jcb_ordered_items_table where transactionId = ?";
		try{
			pst = con.prepareStatement(sql);
			pst.setString(1, id);
			rs = pst.executeQuery();
			while(rs.next()){
				FinalCart cart = new FinalCart();
				cart.setName(rs.getString("itemName"));
				cart.setQuantity(rs.getString("itemQuantity"));
				cart.setTotalPrice(rs.getString("itemTotal"));
				al.add(cart);
			}
		}catch(SQLException e){
			logger.error("fetchFinalCartByTxnID Error :" +e);
		}finally{
			JdbcUtility.conClose(con);
			JdbcUtility.pstClose(pst);
		}
		return al;		
	}
	
	public static int fetchCartSize(String id){
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		int count = 0;
		final String sql = "select * from jcb_ordered_items_table where userId = ? and orderStatus = ?";
		try{
			pst = con.prepareStatement(sql);
			pst.setString(1, id);
			pst.setString(2, "Temp");
			rs = pst.executeQuery();
			while(rs.next()){
				count++;
			}
		}catch(SQLException e){
			logger.error("fetchCartSize Error :" +e);
		}finally{
			JdbcUtility.conClose(con);
			JdbcUtility.pstClose(pst);
		}
		return count;		
	}
	public static String sendOTP(String id) {
		logger.info("sendOTP Called...");
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		PreparedStatement pst1 = null;
		PreparedStatement pst2 = null;
		ResultSet rs = null;
		String status = "";
		final String sql = "select emailId from jcb_user_account_table where userId = ?";
		final String sql1 = "update jcb_otp set otp = ? where userId = ?";
		final String sql2 = "insert into jcb_otp(otp,userId) values(?,?)";
		try{
			pst = con.prepareStatement(sql);
			pst.setString(1, id);
			rs = pst.executeQuery();
			if(rs.next()){
				String otp = String.valueOf(generateOTP());
				String mail = rs.getString("emailId");
				pst1 = con.prepareStatement(sql1);
				pst1.setString(1, otp);
				pst1.setString(2, id);
				int i = pst1.executeUpdate();
				if(i != 0){
					status = "otp generated" ;
					Mail.sendMail(mail, "Your OTP is: "+otp);
				}else{
					pst2 = con.prepareStatement(sql2);
					pst2.setString(1, String.valueOf(generateOTP()));
					pst2.setString(2, id);
					int  j = pst2.executeUpdate();
					if(j!=0){
						status = "otp generated" ;
						Mail.sendMail(mail, "Your OTP is: "+otp);
					}
				}
			}
		}catch(SQLException e){
			status = e.getMessage();
			logger.error("sendOTP Error :" +e);
		}finally{
			JdbcUtility.conClose(con);
			JdbcUtility.pstClose(pst);
		}
		logger.info(status);
		return status;
	}

	public static String validateOTP(String otp) {
		logger.info("validateOTP Called...");
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String status = "";
		final String sql = "select * from jcb_otp where otp = ?";
		try{
			pst = con.prepareStatement(sql);
			pst.setString(1, otp);
			rs = pst.executeQuery();
			if(rs.next()){
				status = "valid" ;
			}else{
				status = "Invalid OTP...";
			}
		}catch(SQLException e){
			status = e.getMessage();
			logger.error("validateOTP Error :" +e);
		}finally{
			JdbcUtility.conClose(con);
			JdbcUtility.pstClose(pst);
		}
		logger.info(status);
		return status;
	}

	public static String changePwdWithOTP(String otp, String newPwd) {
		String hashedNewPwd = generateHash(SALT+newPwd);
		Connection con = JdbcUtility.getConnection();
		PreparedStatement pst = null;
		PreparedStatement pst1 = null;
		PreparedStatement pst2 = null;
		ResultSet rs = null;
		String status = "";
		final String sql = "select userId from jcb_otp where otp = ?";
		final String sql1= "update jcb_user_login_db set password = ? where userid = ?";
		final String sql2 = "update jcb_user_account_table set password =? where userid = ?";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, otp);
			rs = pst.executeQuery();
			if (rs.next()) {
				String userid = rs.getString("userId");
				pst1 = con.prepareStatement(sql1);
				pst1.setString(1, hashedNewPwd);
				pst1.setString(2, userid);
				int row = pst1.executeUpdate();
				pst2 = con.prepareStatement(sql2);
				pst2.setString(1, hashedNewPwd);
				pst2.setString(2, userid);
				int row1 = pst2.executeUpdate();
				if(row != 0 && row1 != 0){
					status = "Password Successfully Updated...";
				}
			}else{
				status = "Invalid OTP";
			}
		} catch (SQLException e) {
			logger.error("changePwdWithOTP Error :" +e);
		} finally {
			JdbcUtility.conClose(con);
			JdbcUtility.rsClose(rs);
			JdbcUtility.pstClose(pst);
			JdbcUtility.pstClose(pst1);
			JdbcUtility.pstClose(pst2);
		}
		return status;
	}



}

	

