package com.jcb.dao;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RejectMedicinesServlet")
	public class RejectMedicinesServlet extends HttpServlet {
	    private static final long serialVersionUID = 1L;

	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        String[] selectedRows = request.getParameterValues("selectedRows");

	        if (selectedRows != null && selectedRows.length > 0) {
	            MedicineDAO medicineDAO = new MedicineDAO();

	            for (String medicineId : selectedRows) {
	                // Perform deletion logic in your DAO class
	                medicineDAO.deleteMedicineById(Integer.parseInt(medicineId));
	            }

	            response.getWriter().write("Selected medicines rejected and deleted successfully.");
	        } else {
	            response.getWriter().write("Selected medicines rejected and deleted successfully.");
	        }
	    }
	}



