
package com.jcb.dao;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/SaveMedicineServlet")
@MultipartConfig
public class SaveMedicineServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String medicineName = request.getParameter("medicineName");
        String medicineGenName = request.getParameter("medicinegenName");
        String manDate = request.getParameter("manDate");
        String expiryDate = request.getParameter("expiryDate");
        String quantity = request.getParameter("qty");

        // Save file to server
        Part filePart = request.getPart("myfile");
        String fileName = getFileName(filePart);

        // Get the real path of the 'uploads' directory
        String uploadDirectory = getServletContext().getRealPath("/uploads");

        // Create the 'uploads' directory if it doesn't exist
        File uploadDir = new File(uploadDirectory);
        if (!uploadDir.exists()) {
            uploadDir.mkdir();
        }

        // Save file to the 'uploads' directory
        String filePath = uploadDirectory + File.separator + fileName;
        filePart.write(filePath);

        // Save data to the database
        saveToDatabase(medicineName, medicineGenName, manDate, expiryDate, quantity, fileName);
        
        request.setAttribute("successMessage", "Medicine uploaded successfully!");
        
     // Forward to index.jsp with success message
        RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/Add_medicine.jsp");
        dispatcher.forward(request, response);
        
         // Redirect back to the form page
    }

    private String getFileName(Part part) {
        String contentDisposition = part.getHeader("content-disposition");
        String[] tokens = contentDisposition.split(";");
        for (String token : tokens) {
            if (token.trim().startsWith("filename")) {
                return token.substring(token.indexOf('=') + 1).trim().replace("\"", "");
            }
        }
        return "";
    }

    private void saveToDatabase(String medicineName, String medicineGenName, String manDate, String expiryDate, String quantity, String fileName) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Load JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Connect to the database (replace with your actual database credentials and connection URL)
            String url = "jdbc:mysql://localhost:3306/jcbpoint?autoReconnect=true&useSSL=false";
            String username = "root";
            String password = "P@ssw0rd2143";
            conn = DriverManager.getConnection(url, username, password);

            // Insert data into the database
            String sql = "INSERT INTO jcbpoint.medicines (medicineName, medicineGenName, manDate, expiryDate, quantity, fileName) VALUES (?, ?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, medicineName);
            pstmt.setString(2, medicineGenName);
            pstmt.setString(3, manDate);
            pstmt.setString(4, expiryDate);
            pstmt.setString(5, quantity);
            pstmt.setString(6, fileName);

            pstmt.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
