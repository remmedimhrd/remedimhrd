package com.jcb.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.jcb.bean.ReqMedicine;
import com.jcb.utility.JdbcUtility;

public class RequestDAO {
	public List<ReqMedicine> getAllMedicines() {
        List<ReqMedicine> medicines = new ArrayList<>();
        String query = "SELECT * FROM requests ";

        try (Connection connection = JdbcUtility.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                ReqMedicine medicine = new ReqMedicine();
                medicine.setId(resultSet.getInt("id"));
                medicine.setUserName(resultSet.getString("userName"));
                medicine.setMedicinebrandName(resultSet.getString("brandName"));
                medicine.setMedicinegenName(resultSet.getString("genericName"));
                medicine.setQuantity(resultSet.getInt("quantity"));
                medicine.setPhoneNum(resultSet.getString("phoneNumber"));
                medicine.setAddress(resultSet.getString("deliveryAddress"));

                medicines.add(medicine);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return medicines;
    }

}
