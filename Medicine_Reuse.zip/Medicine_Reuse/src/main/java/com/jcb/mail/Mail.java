package com.jcb.mail;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;

import com.jcb.dao.JcbDAO;

public class Mail {

	final static Logger logger = Logger.getLogger(Mail.class);
	
	public static String sendMail(String to,String msg){
		logger.info("sendMail called...");
		final String host="mail.inoesissolutions.com";  
		final String user="prakash.mallick@inoesissolutions.com";//change accordingly  
		final String password="pk.626688";//change accordingly  		      
		String status = "";
		//Get the session object  
		Properties props = new Properties();  
		props.put("mail.smtp.host",host);
		props.put("mail.smtp.auth", "true");  

		Session session = Session.getDefaultInstance(props,  
				new javax.mail.Authenticator() {  
			protected PasswordAuthentication getPasswordAuthentication() {  
				return new PasswordAuthentication(user,password);  
			}  
		});  

		//Compose the message  
		try {  
			MimeMessage message = new MimeMessage(session);  
			message.setFrom(new InternetAddress(user));  
			message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
			message.setSubject("Password Reset Form...");  
			message.setText(msg);  

			//send the message  
			Transport.send(message);  
			status = "Mail sent successfully...";  

		} catch (MessagingException e) {
			e.printStackTrace(); 
			status = e.toString();
		}  
		return status;
	}
}
