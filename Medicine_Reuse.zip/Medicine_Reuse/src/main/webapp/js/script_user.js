/**
 * 
 */


  // This function will be called when the "Donate" button is clicked
function donateMedicine() {
    // Get values from the form
    var medicineName = document.getElementById("medicineName").value;
    var medicineGenName = document.getElementById("medicinegenName").value;
    var manDate = document.getElementById("manDate").value;
    var expiryDate = document.getElementById("expiryDate").value;
    var quantity = document.getElementById("qty").value;
    var fileInput = document.getElementById("myfile");

    // Validate the form data (you can add more validation as needed)
    if (!medicineName || !medicineGenName || !manDate || !expiryDate || !quantity || !fileInput.files.length) {
        alert("Please fill in all the fields and choose a file.");
        return;
    }

    // Create a new list item to display the donated medicine
    var listItem = document.createElement("li");
    listItem.innerHTML = `
        <strong>${medicineName}</strong> (Generic: ${medicineGenName})<br>
        Manufacture Date: ${manDate}, Expiry Date: ${expiryDate}<br>
        Quantity: ${quantity}
    `;

    // Append the list item to the medicine list
    var medicineList = document.getElementById("medicine-list");
    medicineList.appendChild(listItem);

    // Optionally, you can clear the form fields after donation
    document.getElementById("donate-form").reset();
}
