$(document).ready(function() {
	$("#addcart").click(function() {
		$.ajax({
			url: "JCBController",
			method: "post",
			data:{name:$("this .caption1 h6").text(),price:$("this .caption1").find("p:first").text(),additemquantity:$("this .caption1").find("#value").text()},
			success:function(data){
				window.location.reload();
			}
		});
	});
	$("#addcart1").click(function() {        
		$.ajax({
			url: "JCBController",
			method: "post",
			data:{name:$(".caption2 h6").text(),price:$(".caption2").find("p:first").text(),additemquantity:$(".caption2").find("#value1").text()},
			success:function(data){
				window.location.reload();
			}
		});
	});
	$("#sdp").click(function() {        
		$.ajax({
			url: "JCBController",
			method: "post",
			data:{deleteitemname:$(".caption2 h6").text()},
			success:function(data){
				window.location.reload();
			}
		});
	});	
});